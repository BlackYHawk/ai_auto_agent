window.registToModule('executeContentLoaded', function(a,b,c,d,e){"use strict";
function main(event, action) {
  const ActionType = window.use("ActionType");
  if (action.strategyKey === "sriDomainCheck") {
    if (action.type === ActionType.REPORT_ONLY) {
      setTimeout(() => {
        const scriptList = document.querySelectorAll("script[src]");
        const linkList = document.querySelectorAll("link[href]");
        const scriptDomainList = Array.from(scriptList).map((i) => i.getAttribute("src")).map((v) => new URL(v, window.location.href).host).filter((v) => v.indexOf(".") !== -1);
        const linkDomainList = Array.from(linkList).map((i) => i.getAttribute("href")).map((v) => new URL(v, window.location.href).host).filter((v) => v.indexOf(".") !== -1);
        const domainList = scriptDomainList.concat(linkDomainList).map((v) => v.split(".").slice(1).join("."));
        const set = {};
        for (const domain of domainList) {
          set[domain] = 1;
        }
        const uniqDomainList = Object.keys(set);
        const whiteList = ["bytegoofy.com", "bytescm.com", "ibytedapm.com", "bytetos.com", "byteimg.com", "yhgfb-cn-static.com", "zijieapi.com", "douyinstatic.com", "douyinvod.com", "douyinpic.com", "snssdk.com", "douyin.com", "bytedance.com", "ibytedapm.com", "bytescm.com", "bytetos.com", "yhgfb-cn-static.com", "bytegoofy.com", "googletagmanager.com", "toutiaostatic.com", "bytednsdoc.com", "zijieapi.com", "toutiaoimg.com", "google-analytics.com", "douyinstatic.com", "toutiao.com"];
        const blackList = uniqDomainList.filter((v) => {
          return whiteList.indexOf(v) === -1;
        });
        const setItem = window.SDKNativeWebApi["API_LOCALSTORAGE_SET"] || localStorage.setItem.bind(localStorage);
        const getItem = window.SDKNativeWebApi["API_LOCALSTORAGE_GET"] || localStorage.getItem.bind(localStorage);
        const storeKey = "webStrategySriDomainCheck";
        const jsonStr = getItem(storeKey);
        let currentBlackList = [];
        let addedBlackList = [];
        if (jsonStr) {
          const _blackList = JSON.parse(jsonStr);
          addedBlackList = blackList.filter((v) => {
            return _blackList.indexOf(v) === -1;
          });
          currentBlackList = _blackList.concat(addedBlackList);
        } else {
          addedBlackList = blackList;
          currentBlackList = blackList;
        }
        const scriptUrlList = Array.from(scriptList).map((i) => i.getAttribute("src"));
        const linkUrlList = Array.from(linkList).map((i) => i.getAttribute("href"));
        const reportUrlList = scriptUrlList.concat(linkUrlList).filter((v) => {
          return addedBlackList.some((domain) => {
            return v.includes(domain);
          });
        });
        if (addedBlackList.length > 0) {
          const reporter = window.use("coreLoader").reporter;
          action.payload.reportUrlList = reportUrlList;
          reporter.report({ event, action, fromStage: "excuteAsync" });
          setItem(storeKey, JSON.stringify(currentBlackList));
        }
      });
    }
  }
  if (action.strategyKey === "proxyFishing") {
    if (action.type === ActionType.BLOCK) {
      setInterval(() => {
        if (window.document.body) {
          window.document.body.innerHTML = "页面渲染安全策略拦截，请联系 Argus Oncall";
        }
      }, 0);
    }
  }
  if (action.strategyKey === "domViolationContent") {
    if (action.type === ActionType.BLOCK) {
      document.body.innerHTML = "";
    }
  }
  if (action.strategyKey === "privacyComponentInit" && action.type === ActionType.REPORT_ONLY) {
    const init = window.use("createPrivacyComponentInit");
    init();
  }
}
; return typeof main !== 'undefined' && main(a,b,c,d,e);});